<link rel="shortcut icon" type="image/png" href="<?php echo e(asset('backend/assets/images/icon/favicon.ico')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/font-awesome.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/themify-icons.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/metisMenu.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/slicknav.min.css')); ?>">
<!-- amchart css -->
<link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
<!-- others css -->
<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/typography.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/default-css.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/styles.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/responsive.css')); ?>">
<!-- modernizr css -->
<script src="<?php echo e(asset('backend/assets/js/vendor/modernizr-2.8.3.min.js')); ?>"></script><?php /**PATH /Users/admin/projects/misc/laravel-role/resources/views/backend/layouts/partials/styles.blade.php ENDPATH**/ ?>