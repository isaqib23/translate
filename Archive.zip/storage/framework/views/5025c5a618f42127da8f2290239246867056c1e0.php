
<!-- footer area start-->
<footer>
    <div class="footer-area">
        <p>© Copyright 2018. All right reserved.</p>
    </div>
</footer>
<!-- footer area end-->
<?php /**PATH /Users/admin/projects/misc/laravel-role/resources/views/backend/layouts/partials/footer.blade.php ENDPATH**/ ?>